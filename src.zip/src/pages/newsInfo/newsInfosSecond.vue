<template>
    <div>
        <!--轮播图区域开始  -->
        <img src="../../assets/images/index/banner_1.gif" class='banner_img'>
        <!-- 轮播图区域结束 -->
        <!--  -->
        <div  class='conten_cccc' >
           <div  class='title' >
               对应标题
           </div>
           <div  class='text_area1 margin_top76' >
为响应民航局局长冯正霖在2018年全国民航工作会议上提出的建设“四型机场”标杆体系，对标一流，打造现代化民用机场的要求，首都机场集团公司将建设“四型机场”作为打造世界一流机场管理集团的核心目标，并将其纳入“4-3-4-1”总体工作思路中。

           </div>
           <div  class='img_2area' >
               <img src="../../assets/images/index/secondary_img2.png"   class='img2' >
                <img src="../../assets/images/index/secondary_img3.png"   class='img2' >
           </div>
                      <div  class='text_area1 margin_top76_bottom' >
过去的一年，首都机场集团公司陆续拟定发布了平安、绿色、智慧、人文机场建设指导纲要，明晰了发展的思路与目标。集团下属各成员机场与专业公司齐头并进、亮点频现，为建设“四型机场”赢得了良好开局，也在打造世界一流机场集团的新征程上迈出了扎实的一步。

           </div>
        </div>
        <!--  -->
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style  scoped>
.banner_img{
    width:100%;
    height:15.4rem;
}
.conten_cccc{
    width:100%;
    padding-left:1.55rem;
    padding-right:1.5rem;
    box-sizing: border-box;
}
.title{
    width:100%;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top:1.8rem;
    height: 1.2rem;
    font-size: 1.2rem;
    font-family: Source Han Sans CN;
    font-weight: bold;
    color: #155BA5;

}
.img1_area{
    width:100%;
    margin-top:53px;
    height:440px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.img1{
    width:870px;
    height:440px;
}
.img2{
    width:16.5rem;
    height:9rem;
}
.text_area1{
    width:100%;
    font-size: 1rem;
    font-family: Source Han Sans CN;
    font-weight: 400;
    color: #333333;
    line-height: 1.3rem;

}
.margin_top76{
     margin-top:1.65rem;
}
.img_2area{
    width:100%;
    height:9rem;
    margin-top:3.45rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.margin_top60{
    margin-top:60px;
}
.margin_bottom100{
    margin-bottom:100px;
}
.margin_top76_bottom{
    margin-top:3.7rem;
    margin-bottom:4.84rem;
}
</style>