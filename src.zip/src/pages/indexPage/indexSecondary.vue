<template>
    <div>
        <div  class='conten_cccc' >
           <div  class='title' >
               企业相关标题
           </div>
           <div class='img1_area' >
               <img src="../../assets/images/index/secondary_img1.png"  class='img1' >
           </div>
           <div  class='text_area1' >
华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。
           </div>
           <div  class='img_2area' >
               <img src="../../assets/images/index/secondary_img2.png"   class='img2' >
                <img src="../../assets/images/index/secondary_img3.png"   class='img2' >
           </div>
            <div  class='text_area1 margin_bottom100' >
               华为智慧机场数据中心解决方案，近年来，智慧机场理念已得到业内的普遍认可，并开始逐步付诸实践。数字化协作、云计算和大数据等新ICT技术带来的变革将赋予传统ICT系统所不具备的能力，重构机场的信息流，在智慧机场的运营安全保障、机场运行效率、面向旅客及企业的服务质量等方面将带来显著效益。
                            
           </div>
        </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
.conten_cccc{
    width:100%;
    box-sizing: border-box;
    padding-left:1.55rem;
    padding-right:1.45rem;
}
.title{
    display: flex;
    justify-content: center;
    align-items: center;
    width:100%;
    height:1.2rem;
    margin-top:2.45rem;
    font-size:1.2rem;
    font-family:Source Han Sans CN;
    font-weight:bold;
    color:rgba(21,91,165,1);
}
.img1_area{
    margin-top:2.75rem;
    display: flex;
    justify-content: center;
    align-items: center;
    width:100%;
    height:13.55rem;
}
.img1{
    width:26.55rem;
    height:13.55rem;
}
.text_area1{
    margin-top:2.5rem;
    width:100%;
    font-size:1rem;
    font-family:Source Han Sans CN;
    font-weight:400;
    color:rgba(51,51,51,1);
    line-height:1.3rem;
}
.img_2area{
    margin-top:2.75rem;
   width:100%;
   height:9rem;
   display: flex;
   justify-content: space-between;
   align-items: center;
}
.img2{
    width:16.5rem;
    height:9rem;
}
.margin_bottom100{
   margin-bottom:3.75rem;
}
</style>