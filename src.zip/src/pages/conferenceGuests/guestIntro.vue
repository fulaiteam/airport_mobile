<template>
    <div>
       <!--轮播图区域开始  -->
        <img src="../../assets/images/index/banner_1.gif" class='banner_img'>
        <!-- 轮播图区域结束 -->
        <!--版心区域开始  -->
        <div class='intro_middle_content'  >
            <div class='title' >
                嘉宾介绍
            </div>
            <div  class='flrx_content_center' >
                <img  class='img_area'  src="../../assets/images/conference/person.png" >
            </div>
            <div  class='flrx_content_center'  >
                <img   src='../../assets/images/conference/watch_btn.png'  class='watch_btn' />
            </div>
            <div  class='flrx_content_center'  >
               <div  class='black_title' >领导介绍</div>
            </div>
                    </div>
        <!-- 版心区域结束 -->

            <div   class='grey_line' ></div>
            <!--版心区域开始  -->
        <div class='intro_middle_content'  >
            <div  class='text_area' >
工作履历：1991.07－1992.05 北京市通县胡各庄乡人民政府干事 1992.05－1993.07 北京市通县民政局干事 1993.07－1994.12 北京市通县政府办办事员 1994.12－1998.12 北京市通县（通州区）政府办信息科副科长 1998.12－2003.03 北京市通州区政府办督察室主任 2003.03－2005.06 北京市民政局副局长 2005.06－2006.05 北京市通州区民政局党委委员、副局长 2006.05－2010.08 北京市通州区宋庄镇党委委员、副书记、镇长 2010.08－2012.11 北京市通州区新城建设管理委员会调研员、新城运营公司董事长 2012.11－2013.11 北京市通州区人民政府国有资产监督管理委员会调研员 2013.11－2014.02 北京市通州区环境保护局书记 2014.02－2019.03 北京市通州区环境保护局书记、局长 2019.03－2019.09 北京市通州区交通局党委书记、局长 2019.09－至今 北京市通州区交通局党组书记、局长
                             
                            
            </div>
                        <div  class='flrx_content_center'  >
               <div  class='black_title' >企业介绍</div>
            </div>
                                </div>
        <!-- 版心区域结束 -->

            <div   class='grey_line' ></div>
            <!--版心区域开始  -->
             <div class='intro_middle_content'  >
            <div class='text_area margin_bottom_1' >
首都机场集团公司（英文缩写CAH）隶属于中国民用航空局，是一家以机场业为核心的跨地域的大型国有企业集团。 公司旗下拥有北京、天津、江西、河北、吉林、内蒙古、黑龙江等8省（直辖市、自治区）所辖干支机场20多个，并参股沈阳、大连机场，2010年，首都机场集团公司实现旅客吞吐量1.43亿人次，为我国最大的机场集团。
            </div>
            </div>
        </div>
        <!-- 版心区域结束 -->
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style  scoped>
.banner_img{
    width:100%;
    height:15.4rem;
}
.intro_middle_content{
    width:100%;
    padding-left:1.55rem;
    padding-right:1.5rem;
    box-sizing: border-box;

}
.title{
    margin-top:2rem;
    width: 100%;
    height: 1.2rem;
    font-size: 1.2rem;
    font-family: Source Han Sans CN;
    font-weight: bold;
    color: #155BA5;
    display: flex;
    justify-content: center;
}
.flrx_content_center{
    width:100%;
    display: flex;
    overflow: hidden;
    justify-content: center;
}
.img_area{
    height:19.05rem;
    width:16.55rem;
    margin-top:1.9rem;
}
.watch_btn{
    margin-top:1.1rem;
    width:6rem;
    height:1.6rem;
}
.black_title{
    width: 100%;
    height: 1.1rem;
    font-size: 1.1rem;
    font-family: Source Han Sans SC;
    font-weight: 500;
    color: #535353;
    line-height: 1.3rem;
    display: flex;
    overflow: hidden;
    justify-content: center;
    margin-top:2rem;
}
.grey_line{
    width:100%;
    margin-top:1rem;
    height:1px;
    border-top:1px solid rgba(230,230,230,1);
}
.text_area{
    width:100%;
    margin-top:1rem;
    font-size: 1rem;
    font-family: Source Han Sans CN;
    font-weight: 400;
    color: #535353;
    line-height: 1.3rem;

}
.margin_bottom_1{
    margin-bottom:3.4rem;
}
</style>